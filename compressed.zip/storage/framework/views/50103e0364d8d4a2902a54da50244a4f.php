<header
    class="h-16 bg-white shadow flex items-center justify-between px-6"
>
    <div class="flex items-center justify-start gap-3">
        <div class="flex items-center justify-end">
            <button
                @click="open = !open"
                class=" cursor-pointer gray-900"
            >
                ☰
            </button>
        </div>

        <h1 class="text-xl font-bold">
            NRC
        </h1>
    </div>



    <div class="flex items-center gap-6">














        <!-- Profile -->
        <button class="flex items-center gap-2 cursor-pointer">






            <span>
                Admin
            </span>

        </button>

        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('auth.logout', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-1386663463-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>


    </div>

</header>
<?php /**PATH D:\Wesam\HealGenAPI\resources\views/livewire/layout/header.blade.php ENDPATH**/ ?>