<div class="mt-8 bg-white rounded-lg shadow">

    <div class="p-4 border-b">
        <h2 class="text-lg font-semibold">
            Latest Patients
        </h2>
    </div>

    <div class="overflow-x-auto">

        <table class="min-w-full text-sm">

            <thead class="bg-gray-100">
            <tr>
                <th class="px-4 py-3 text-left">Patient ID</th>
                <th class="px-4 py-3 text-left">Donor ID</th>
                <th class="px-4 py-3 text-left">Cup Lot</th>
                <th class="px-4 py-3 text-left">Status</th>
                <th class="px-4 py-3 text-left">Processed At</th>
                <th class="px-4 py-3 text-center">Action</th>
            </tr>
            </thead>

            <tbody>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                <tr class="border-b hover:bg-gray-50">

                    <td class="px-4 py-3">
                        <?php echo e($patient->PatientId); ?>

                    </td>

                    <td class="px-4 py-3">
                        <?php echo e($patient->DonorId); ?>

                    </td>

                    <td class="px-4 py-3">
                        <?php echo e($patient->CupLotNumber); ?>

                    </td>

                    <td class="px-4 py-3">
                        <?php echo e($patient->Status); ?>

                    </td>

                    <td class="px-4 py-3">
                        <?php echo e($patient->ProcessedAt); ?>

                    </td>

                    <td class="px-4 py-3 text-center">

                        <a
                            href="<?php echo e(route('tests.details', $patient->Id)); ?>"
                            class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 cursor-pointer"
                        >
                            Edit
                        </a>

                    </td>

                </tr>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                <tr>
                    <td colspan="6" class="text-center py-8 text-gray-500">
                        No records found.
                    </td>
                </tr>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            </tbody>

        </table>

        <div class="mt-6">
            <?php echo e($patients->links()); ?>

        </div>

    </div>

</div>
<?php /**PATH D:\Wesam\HealGenAPI\resources\views/livewire/Tests/tests.blade.php ENDPATH**/ ?>