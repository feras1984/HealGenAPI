<div>

    <h1 class="text-2xl font-bold mb-5">
        HIS Logs
    </h1>

    <div class="bg-gray-900 text-green-400 p-5 rounded-lg shadow overflow-auto h-[600px]">
        <pre class="whitespace-pre-wrap text-sm"><?php echo e($content); ?></pre>
    </div>

</div>
<?php /**PATH D:\Wesam\HealGenAPI\resources\views/livewire/logs.blade.php ENDPATH**/ ?>