<form method="POST" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>

    <button
        type="submit"
        class="flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-gray-100 transition cursor-pointer"
    >
        🚪
        <span>Logout</span>
    </button>
</form>
<?php /**PATH D:\Wesam\HealGenAPI\resources\views/livewire/auth/logout.blade.php ENDPATH**/ ?>