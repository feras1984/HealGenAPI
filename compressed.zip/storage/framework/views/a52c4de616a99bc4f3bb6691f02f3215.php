<div>
    <h1 class="text-2xl font-bold">
        Dashboard
    </h1>

    <div class="grid grid-cols-3 gap-6 mt-6">

        <div class="bg-white p-6 rounded shadow">
            Total Patients: <?php echo e($totalPatients); ?>

        </div>

        <div class="bg-white p-6 rounded shadow">
            Pending HL7 Messages: <?php echo e($pendingMessages); ?>

        </div>

        <div class="bg-white p-6 rounded shadow">
            Failed Imports: <?php echo e($failedMessages); ?>

        </div>

    </div>
</div>
<?php /**PATH D:\Wesam\HealGenAPI\resources\views/livewire/dashboard.blade.php ENDPATH**/ ?>