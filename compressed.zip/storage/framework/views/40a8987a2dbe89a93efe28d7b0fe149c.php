<div class="flex items-center gap-2">
    <img
        src="<?php echo e(asset('images/logo.png')); ?>"
        alt="Logo"
        class="h-10 w-auto"
    >

    <span class="font-bold text-lg">
        NRC
    </span>
</div>
<?php /**PATH D:\Wesam\HealGenAPI\resources\views/livewire/components/logo.blade.php ENDPATH**/ ?>