<?php

namespace App\Livewire\Components;

use Livewire\Component;

class Logo extends Component
{
    public function render()
    {
        return view('livewire.components.logo');
    }
}
